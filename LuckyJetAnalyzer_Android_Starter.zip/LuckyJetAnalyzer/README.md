# Lucky Jet Analyzer — proyecto Android inicial

**Esto es código fuente de un prototipo, no un APK compilado ni una app lista para apostar.**

## Incluye
- Cámara en vivo con CameraX.
- Reconocimiento de texto con Google ML Kit.
- Lectura básica de números con formato `1.25x` o `2,50x`.
- Frecuencias descriptivas de las lecturas detectadas e historial temporal.

## Limitaciones
- La versión inicial no distingue de forma fiable un multiplicador que sigue subiendo del multiplicador final de la ronda. Puede registrar valores incorrectos o duplicados.
- Debe probarse y adaptarse a la interfaz exacta de Lucky Jet, idealmente con confirmación visual del final de cada ronda.
- Los porcentajes describen las lecturas capturadas, no la probabilidad de la próxima ronda.
- No se conecta a 1win, no automatiza apuestas y no predice resultados.
- El OCR se ejecuta en el dispositivo. Se solicita permiso de cámara.

## Abrir y compilar
1. Instalar Android Studio y un JDK compatible.
2. Abrir esta carpeta en Android Studio y esperar la sincronización de Gradle.
3. Conectar un Android o usar un emulador con cámara.
4. Ejecutar y conceder permiso de cámara.
5. Para crear un APK de prueba: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

Se necesita compilar y probar en un dispositivo real antes de considerar fiable el reconocimiento.
