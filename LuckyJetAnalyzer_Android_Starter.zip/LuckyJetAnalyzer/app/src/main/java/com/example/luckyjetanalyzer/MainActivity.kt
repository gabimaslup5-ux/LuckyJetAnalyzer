package com.example.luckyjetanalyzer

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Button
import android.widget.ScrollView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var statusText: TextView
    private lateinit var statsText: TextView
    private lateinit var resultsText: TextView
    private val executor = Executors.newSingleThreadExecutor()
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val processing = AtomicBoolean(false)
    private val results = mutableListOf<Double>()
    private var lastDetected: Double? = null
    private var lastDetectedAt = 0L

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startCamera()
            else statusText.text = "Permiso de cámara denegado. Habilitalo en Ajustes."
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED) startCamera()
        else permissionLauncher.launch(Manifest.permission.CAMERA)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            setBackgroundColor(0xFF101A16.toInt())
        }
        val title = TextView(this).apply {
            text = "Lucky Jet Analyzer"; textSize = 24f
            setTextColor(0xFF78E2B5.toInt()); gravity = Gravity.CENTER
        }
        statusText = TextView(this).apply {
            text = "Preparando cámara…"; textSize = 14f
            setTextColor(0xFFFFFFFF.toInt()); setPadding(0, 10, 0, 10)
        }
        previewView = PreviewView(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 260)
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
        statsText = TextView(this).apply {
            textSize = 16f; setTextColor(0xFFFFFFFF.toInt()); setPadding(0, 12, 0, 12)
        }
        resultsText = TextView(this).apply {
            textSize = 14f; setTextColor(0xFFD8E8E0.toInt())
        }
        val clearButton = Button(this).apply {
            text = "Borrar historial"
            setOnClickListener {
                results.clear(); lastDetected = null; updateStats()
                Toast.makeText(this@MainActivity, "Historial borrado", Toast.LENGTH_SHORT).show()
            }
        }
        val note = TextView(this).apply {
            text = "La cámara lee números visibles; puede confundir el multiplicador en curso con el final. Las estadísticas no predicen la próxima ronda."
            textSize = 12f; setTextColor(0xFFB8C9C0.toInt()); setPadding(0, 12, 0, 0)
        }
        root.addView(title); root.addView(statusText); root.addView(previewView); root.addView(statsText)
        root.addView(ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
            addView(resultsText)
        })
        root.addView(clearButton); root.addView(note)
        setContentView(root)
        updateStats()
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            analysis.setAnalyzer(executor) { proxy ->
                val mediaImage = proxy.image
                if (mediaImage == null || !processing.compareAndSet(false, true)) {
                    proxy.close(); return@setAnalyzer
                }
                val image = InputImage.fromMediaImage(mediaImage, proxy.imageInfo.rotationDegrees)
                recognizer.process(image)
                    .addOnSuccessListener { text ->
                        val match = MULTIPLIER_REGEX.findAll(text.text)
                            .mapNotNull { it.groupValues.getOrNull(1)?.replace(',', '.')?.toDoubleOrNull() }
                            .firstOrNull { it >= 1.0 && it <= 1000000.0 }
                        if (match != null) maybeAddResult(match)
                    }
                    .addOnCompleteListener { processing.set(false); proxy.close() }
            }
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
                statusText.text = "Cámara activa: apuntá al teléfono con Lucky Jet visible."
            } catch (e: Exception) {
                statusText.text = "No se pudo iniciar la cámara: ${e.localizedMessage ?: "error"}"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    @Synchronized
    private fun maybeAddResult(value: Double) {
        val now = System.currentTimeMillis()
        // Debounce básico; no confirma que el valor sea el multiplicador final de la ronda.
        if (lastDetected != null && lastDetected == value && now - lastDetectedAt < 4000) return
        if (lastDetected != null && now - lastDetectedAt < 1500) return
        lastDetected = value; lastDetectedAt = now
        runOnUiThread {
            results.add(0, value)
            if (results.size > 500) results.removeAt(results.lastIndex)
            statusText.text = String.format(Locale.US, "Lectura: %.2fx · confirmar visualmente", value)
            updateStats()
        }
    }

    private fun updateStats() {
        val n = results.size
        if (n == 0) {
            statsText.text = "Lecturas detectadas: 0\nFrecuencias históricas: esperando datos"
            resultsText.text = "Todavía no hay multiplicadores detectados."
            return
        }
        fun pct(t: Double) = results.count { it >= t } * 100.0 / n
        statsText.text = String.format(
            Locale.US,
            "Lecturas detectadas: %d\nPromedio de lecturas: %.2fx\n≥2x: %.1f%%   ≥5x: %.1f%%   ≥10x: %.1f%%\nCalidad: revisar; OCR puede leer multiplicadores en curso.",
            n, results.average(), pct(2.0), pct(5.0), pct(10.0)
        )
        resultsText.text = results.take(100).mapIndexed { i, v ->
            String.format(Locale.US, "%d. %.2fx", i + 1, v)
        }.joinToString("\n")
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdown()
        recognizer.close()
    }

    companion object {
        private val MULTIPLIER_REGEX = Regex(
            "(?:^|[^A-Za-z0-9])([0-9]{1,6}(?:[.,][0-9]{1,3})?)\\s*[xX](?:[^A-Za-z0-9]|$)"
        )
    }
}
